class Test4 extends Test2 {

}
class Validate {
    constructor(a) {
        this.a = a;
    }
}